"""Aphelion trading platform packages."""

