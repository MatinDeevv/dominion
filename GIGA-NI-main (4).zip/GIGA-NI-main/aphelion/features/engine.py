"""
Compatibility shim for the legacy bar-driven feature engine.

Canonical ownership now lives under ``aphelion.feature_engine``.
"""

from aphelion.feature_engine.legacy_runtime import LegacyFeatureEngine

FeatureEngine = LegacyFeatureEngine

__all__ = ["FeatureEngine"]
